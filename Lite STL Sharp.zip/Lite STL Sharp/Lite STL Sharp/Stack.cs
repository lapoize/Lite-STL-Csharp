﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lite_STL_Sharp
{
    public class Stack<T>
    {
        private StackNode<T> Head;
        Exception NullTopEx = new Exception("Null stack head");
        public Stack()
        {
            Head = null;
        }
        public void Push(T data)
        {
            StackNode<T> s = new StackNode<T>(data)
            {
                Next = Head
            };
            Head = s;
        }
        public void Pop()
        {
            if (Head == null)
            {
                throw NullTopEx;
            }
            Head = Head.Next;
        }
        public T GetTop()
        {
            if (Head == null)
            {
                throw NullTopEx;
            }
            return Head.Data;
        }
        public int GetHeight()
        {
            StackNode<T> t = Head;
            int len = 0;
            while (t != null)
            {
                ++len;
                t = t.Next;
            }
            return len;
        }
        public void Clear()
        {
            Head = null;
        }
    }
    public class StackNode<T>
    {
        public T Data;
        public StackNode<T> Next;
        public StackNode()
        {
            Data = default(T);
            Next = null;
        }
        public StackNode(T data)
        {
            Data = data;
            Next = null;
        }
        public StackNode(StackNode<T> next)
        {
            Data = default(T);
            Next = next;
        }
        public StackNode(T data, StackNode<T> next)
        {
            Data = data;
            Next = next;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lite_STL_Sharp
{
    public class LinkedList<T>
    {
        Exception NullLinkListEx = new Exception("Null LinkList");
        Exception NullLLorNoIndx = new Exception("Null LinkList or index out of range");
        Exception OutofIndexRang = new Exception("Index out of range");
        public T this[int index]
        {
            get
            {
                return GetElem(index);
            }
            set
            {
                EditElem(index, value);
            }
        }
        private LinkListNode<T> Head { get; set; }
        public LinkedList()
        {
            Head = null;
        }
        public int GetLength()
        {
            LinkListNode<T> p = Head;
            int len = 0;
            while (p != null)
            {
                ++len;
                p = p.Next;
            }
            return len;
        }
        public void Clear()
        {
            Head = null;
        }
        public bool IsEmpty()
        {
            if (Head == null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void Append(T item)
        {
            LinkListNode<T> q = new LinkListNode<T>(item);
            LinkListNode<T> p = new LinkListNode<T>();
            if (Head == null)
            {
                Head = q;
                return;
            }
            p = Head;
            while (p.Next != null)
            {
                p = p.Next;
            }
            p.Next = q;
        }
        public void Insert(T item, int i)
        {

            if (IsEmpty() || i < 1 || i > GetLength())
            {
                throw NullLLorNoIndx;
            }
            if (i == 1)
            {
                LinkListNode<T> q = new LinkListNode<T>(item)
                {
                    Next = Head
                };
                Head = q;
                return;
            }
            LinkListNode<T> p = Head;
            LinkListNode<T> r = new LinkListNode<T>();
            int j = 1;
            while (p.Next != null && j < i)
            {
                r = p;
                p = p.Next;
                ++j;
            }
            if (j == i)
            {
                LinkListNode<T> q = new LinkListNode<T>(item)
                {
                    Next = p
                };
                r.Next = q;
            }
        }
        public void InsertPost(T item, int i)
        {
            if (IsEmpty() || i < 1 || i > GetLength())
            {
                throw NullLLorNoIndx;
            }
            if (i == 1)
            {
                LinkListNode<T> q = new LinkListNode<T>(item)
                {
                    Next = Head.Next
                };
                Head.Next = q;
                return;
            }
            LinkListNode<T> p = Head;
            int j = 1;
            while (p != null && j < i)
            {
                p = p.Next;
                ++j;
            }
            if (j == i)
            {
                LinkListNode<T> q = new LinkListNode<T>(item)
                {
                    Next = p.Next
                };
                p.Next = q;
            }
        }
        public T Delete(int i)
        {
            if (IsEmpty() || i < 0 || i > GetLength())
            {
                throw NullLLorNoIndx;
            }
            LinkListNode<T> q = new LinkListNode<T>();
            if (i == 1)
            {
                q = Head;
                Head = Head.Next;
                return q.Data;
            }
            LinkListNode<T> p = Head;
            int j = 1;
            while (p.Next != null && j < i)
            {
                ++j;
                q = p;
                p = p.Next;
            }
            if (j == i)
            {
                q.Next = p.Next;
                return p.Data;
            }
            else
            {
                throw OutofIndexRang;
            }
        }
        public void EditElem(int i, T data)
        {
            if (IsEmpty() || i < 0)
            {
                throw NullLinkListEx;
            }
            LinkListNode<T> p = new LinkListNode<T>();
            p = Head;
            int j = 0;
            while (p.Next != null && j < i)
            {

                ++j;
                p = p.Next;
            }
            if (j == i)
            {
                p.Data = data;
            }
            else
            {
                throw OutofIndexRang;
            }
        }
        public T GetElem(int i)
        {
            if (IsEmpty() || i < 0)
            {
                throw NullLinkListEx;
            }
            LinkListNode<T> p = new LinkListNode<T>();
            p = Head;
            int j = 0;
            while (p.Next != null && j < i)
            {

                ++j;
                p = p.Next;
            }
            if (j == i)
            {
                return p.Data;
            }
            else
            {
                throw OutofIndexRang;
            }
        }
        public int Locate(T value)
        {
            if (IsEmpty())
            {
                throw NullLinkListEx;
            }
            LinkListNode<T> p = new LinkListNode<T>();
            p = Head;
            int i = 1;
            while (!p.Data.Equals(value) && p.Next != null)
            {
                p = p.Next;
                ++i;
            }
            return i;
        }
    }
    public class LinkListNode<T>
    {
        public T Data { get; set; }
        public LinkListNode<T> Next { get; set; }
        public LinkListNode(T item, LinkListNode<T> p)
        {
            Data = item;
            Next = p;
        }
        public LinkListNode(LinkListNode<T> p)
        {
            Next = p;
        }
        public LinkListNode(T val)
        {
            Data = val;
            Next = null;
        }
        public LinkListNode()
        {
            Data = default(T);
            Next = null;
        }
    }
}

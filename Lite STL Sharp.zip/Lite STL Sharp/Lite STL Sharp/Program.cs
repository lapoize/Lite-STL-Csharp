﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lite_STL_Sharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Lite_STL_Sharp.LinkedList<int> a = new LinkedList<int>();
            System.Collections.Generic.List<int> p = new System.Collections.Generic.List<int>();
            a.Append(100);
            a.Append(50);
            a.Append(75);
            for (int i=0;i<a.GetLength();i++)
            {
                Console.WriteLine(a[i]);
            }
            a[2] = 55;
            Console.WriteLine(a[1]);
            Console.ReadKey();

            Lite_STL_Sharp.Stack<int> b = new Stack<int>();
            b.Push(100);
            b.Push(50);
            b.Push(75);
            int h = b.GetHeight();
            for (int i=0;i<h;i++)
            {
                Console.WriteLine(b.GetTop());
                b.Pop();
            }
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lite_STL_Sharp
{
    public class Deques<T>
    {
        public Deques()
        {

        }
    }
}
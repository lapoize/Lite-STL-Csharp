﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lite_STL_Sharp
{
    public class Queue<T>
    {
        Exception NullTopEx = new Exception("Null queue");
        public int Length
        {
            get;
            private set;
        }
        private QueueNode<T> Head;
        public Queue()
        {
            Head = new QueueNode<T>();
            Length = 0;
        }
        public void Push(T data)
        {
            QueueNode<T> newNode = new QueueNode<T>(data, Head);
            Length += 1;
            Head = newNode;
        }
        public void Pop()
        {
            if (Head == null)
            {
                throw NullTopEx;
            }
            Head = Head.Next;
        }
        public T GetFront()
        {
            if (Head == null)
            {
                throw NullTopEx;
            }
            return Head.Data;
        }
        public int GetLength()
        {
            QueueNode<T> t = Head;
            int len = 0;
            while (t != null)
            {
                ++len;
                t = t.Next;
            }
            return len;
        }
        public void Clear()
        {
            Head = null;
        }
    }
    public class QueueNode<T>
    {
        public T Data;
        public QueueNode<T> Next;
        public QueueNode()
        {
            Data = default(T);
            Next = null;
        }
        public QueueNode(T data)
        {
            Data = data;
            Next = null;
        }
        public QueueNode(QueueNode<T> next)
        {
            Data = default(T);
            Next = next;
        }
        public QueueNode(T data, QueueNode<T> next)
        {
            Data = data;
            Next = next;
        }
    }
}
